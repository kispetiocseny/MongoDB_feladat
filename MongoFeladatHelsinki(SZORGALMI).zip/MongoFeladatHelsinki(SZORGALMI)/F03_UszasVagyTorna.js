//3) Listázza ki az azokat a sportágakat, amik torna vagy úszás sportágból vannak. A megjelenített adatokból, csak a sportág neve és a versenyszám neve látszódjon.

 //Adat feltöltése adatbázisba
 var MongoClient = require("mongodb").MongoClient;
 var url = ""
 ;
 
 async function UszasVagyTorna() {
   try {
    const client = await MongoClient.connect(url);
    console.log("Sikeres csatlakozás");

    const db = client.db("feladatok");
    const collection = db.collection("helsinki");
     
     const szurtAdat = await collection.find({},{
         projection:{
             _id:0,
             SportAg:1,
             VersenySzam:1
         }
     }).toArray();
 
     console.log(szurtAdat);
 
     client.close();
   } catch (err) {
     console.error("Hiba történt a csatlakozás vagy a lekérdezés közben:", err);
   }
 }
 
 UszasVagyTorna();