//4) Listázd ki azokat a versenyszámokat, ahol dobogós helyezést ért el a magyar csapat.
var MongoClient = require("mongodb").MongoClient;
var url = ""
;
async function Dobogo() {
  try {
   const client = await MongoClient.connect(url);
   console.log("Sikeres csatlakozás");

   const db = client.db("feladatok");
   const collection = db.collection("helsinki");
    
   const szurtAdat = await collection.find({ Helyezes: { $lt: 4 } }, {
    projection: {
        _id: 0,
        VersenySzam: 1
    }
}).toArray();

    console.log(szurtAdat);

    client.close();
  } catch (err) {
    console.error("Hiba történt a csatlakozás vagy a lekérdezés közben:", err);
  }
}

Dobogo();