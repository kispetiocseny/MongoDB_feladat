//1) Hozzon létre egy kollekciót "Helsinki" néven.MongoDB segítségével, Atlas felhőszolgáltatásba!
var MongoClient = require("mongodb").MongoClient;
var url = ""
;

async function KollekcioLetrehozasa(){
    try{
        const client=await MongoClient.connect(url);
        const db =client.db("feladatok");
        await db.createCollection("helsinki");
        console.log("A helsinki collection létrejött a feladatok belül.");
        client.close();
    }
    catch(err){
        console.error("Hiba történt a kollekció létrehozása közben.", err)
    }
}
KollekcioLetrehozasa();