//6) Listázd ki azokat a sportágakat, amikben egyéniben szereztek a magyarok aranyérmet.

//Adat feltöltése adatbázisba
var MongoClient = require("mongodb").MongoClient;
var url = ""
;
async function EgyeniErem() {
    try {
        const client = await MongoClient.connect(url);
        console.log("Sikeres csatlakozás");

        const db = client.db("feladatok");
        const collection = db.collection("helsinki");

        const szurtAdat = await collection.find({ Helyezes: 1, CsapatMeret: { $lt: 2 } }, 
            {
            projection:
            {
                _id: 0,
                Helyezes: 0,
                CsapatMeret: 0,
                VersenySzam: 0
            }
        }).toArray();

        console.log(szurtAdat);

        client.close();
    } catch (err) {
        console.error("Hiba történt a csatlakozás vagy a lekérdezés közben:", err);
    }
}

EgyeniErem();
