//5) Jelenítsd meg a legnagyobb csapatmérettel rendelkező versenyszám csapatának minden adatát.
var MongoClient = require("mongodb").MongoClient;
var url = ""
;

async function BigTeam() {
  try {
   const client = await MongoClient.connect(url);
   console.log("Sikeres csatlakozás");

   const db = client.db("feladatok");
   const collection = db.collection("helsinki");
    
   const beolvasottAdatok={CsapatMeret:-1};
   const szurtAdat = await collection.find({}, {
    projection: {
        _id: 1,
        Helyezes:1,
        CsapatMeret:1,
        SportAg:1,
        VersenySzam: 1
    }
}).sort(beolvasottAdatok).limit(1).toArray();

    console.log(szurtAdat);

    client.close();
  } catch (err) {
    console.error("Hiba történt a csatlakozás vagy a lekérdezés közben:", err);
  }
}

BigTeam();